%%%%%%fourier Mellin transform%%%%%%%

function I = teliko_offfm_gpapak(img,pmax)

%%%%%%% Initialization
img =double(img)./255;
N=size(img,1);
r=zeros(N,N);
th=zeros(N,N);
I=zeros(pmax+1,pmax+1);
c1=sqrt(2)/(N-1);
c2=-1/sqrt(2);

%%%%%%% Centroid computation
m=zeros([2,2]);
for p=0:1
    for q=0:1
        s=0;
        for ii=0:N-1
            for jj=0:N-1
                x = (c1*ii+c2);
                y = (c1*jj+c2);
        
                s=s+x^p*y^q*img(ii+1,jj+1);
            end
        end
        m(p+1,q+1) = s;
    end
end
x_average=m(2,1)/m(1,1);
y_average=m(1,2)/m(1,1);


%%%%%%% Image mapping - circle outside
for ii=0:N-1
    for jj=0:N-1
        
        x = (c1*ii+c2)-x_average;
        y = (c1*jj+c2)-y_average;
        
        r(ii+1,jj+1)=sqrt(x^2+y^2);
        th(ii+1,jj+1)=atan2(y,x);
    end
end

%%%%%%% Moments computation
Z=zeros(pmax+1,pmax+1);
for p=0:pmax
    for q=0:pmax       
        Eq = exp(-1i*q*th);        
        Qp=0;
        for k=0:p
            Cpk=((-1)^(p+k)*factorial(p+k+1))/(factorial(p-k)*factorial(k)*factorial(k+1));            
            Qp=Qp + Cpk*(r.^k);
        end        
        Z(p+1,q+1)=((2*(p+1))/(pi*(N-1)^2))*sum(sum(Qp.*Eq.*img));
    end
end


%%%%%%% Invariants computation
thf=angle(Z(2,2));
Gf=sqrt(Z(1,1));
for p=0:pmax
    for q=0:pmax
        s=0;
        for k=0:p
            
            meros_1=exp(-1i*q*thf)*((p+1)/(k+1));
            
            meros_2=0;
            for l=k:p
                Cpl=((-1)^(p+l)*factorial(p+l+1))/(factorial(p-l)*factorial(l)*factorial(l+1));
                dpl=((2*k+2)*factorial(l)*factorial(l+1))/(factorial(l-k)*factorial(l+k+2));
                meros_2=meros_2+Gf^(-(l+2))*Cpl*dpl;
            end
            s = s + meros_1*meros_2*Z(k+1,q+1);
        end
        I(p+1,q+1) = abs(s);
    end
end








