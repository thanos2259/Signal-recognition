%%%%%%%%%%%Create image dataset features array temp%%%%%%%%%%%%

p=3;
files = dir('*.jpg');
b=zeros(p+1,p+1,length(files));
for i = 1 :length(files)
    filename = files(i).name;
    file = imread(filename);
    file = rgb2gray(file);
    level = graythresh(file);
    file = im2bw(file,level);
    file = 1-file;
    file1 = teliko_offfm_gpapak(file,p);
    b(:,:,i)=file1;
        
end

temp=zeros((p+1)*(p+1),length(files));
for l=1:length(files)
    for m=1:p+1
        for n=1:p+1
            temp((p+1)*(m-1)+n,l) = b(m,n,l);
        end
    end
end

t=zeros(length(files)/18,length(files));
cur=1;
for ii=1:length(files)/18
    for k=1:18
        t(cur,18*(ii-1)+k)=1;
    end
    cur=cur+1;
end

net=newff(temp,t,length(files)/18);
net = train(net,temp,t);
y2 = sim(net,temp);


swsta=0;
ola=0;
for ii=1:length(files)
    max=y2(1,ii);
    thesi=1;
    for jj=1:length(files)/18
        if y2(jj,ii)>max
            thesi=jj;
            max=y2(jj,ii);
        end
    end
    if mod(ii,18)==0
        if thesi==ii/18
        swsta=swsta+1;
        end
    else
        z=ii/18;
        z=floor(z);
        z=z+1;
        if thesi==z
            swsta=swsta+1;
        end
    end
    ola=ola+1;
end

pososto=swsta/ola;
